Mosquitto is now installed as a Windows service. You can start/stop it from
the control panel as well as running it as a normal executable.

When running as a service, the configuration in mosquitto.conf in the
installation directory is used so modify this to your needs.
